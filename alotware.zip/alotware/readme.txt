
			Alotware Operating System

Introduction:			
	Alotware is a simple 32-bit self-hosting operating system
	written entirely in an assembly language.
	It is a mono-tasking operating system. More than
	one applications can be loaded, however, one application
	can be executed at a time.
	
Features:
	Well commented code.
	Text editor.
	FASM assembler port.
	2048-like game.
	BIOS disk-access.
	FAT 16 Read/Write.
	VESA and mouse support.
	Graphics Mode fonts.
	API with more than 40 system call.
	and more in near future.
	
To build:
	Run "build.sh" script.

To Install to USB:
	Modify "install.sh" and run it.
